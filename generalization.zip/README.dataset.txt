# generra > generra
https://universe.roboflow.com/testesship/generra

Provided by a Roboflow user
License: CC BY 4.0

